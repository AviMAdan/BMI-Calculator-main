import 'dart:ui';

import 'package:flutter/material.dart';

Color lightbackground = Color.fromARGB(255, 216, 214, 214);
Color darkbackground = Color.fromARGB(255, 1, 30, 54);
Color shadow = Color.fromARGB(255, 94, 219, 241);
