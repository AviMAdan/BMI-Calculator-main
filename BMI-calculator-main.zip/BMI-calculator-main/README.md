#BMI APP

Body mass index (BMI) is a measure of body fat based on height and weight that applies to adult men and women.
 
A Flutter Project

https://user-images.githubusercontent.com/96865753/223666015-de1066cb-1d93-46f8-b748-e2e93887ee92.mp4
